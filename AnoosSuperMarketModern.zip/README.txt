# Anoos Super Market Website

## How to Publish on GitHub Pages

1. Go to https://github.com and create a new repository.
2. Name it: `anoos-super-market` (or anything you like).
3. Upload the `index.html` file.
4. Go to **Settings → Pages**.
5. Under **Source**, select **Deploy from branch**.
6. Choose the `main` branch and root folder.
7. Click **Save**.

Your website will be live at:

`https://yourusername.github.io/anoos-super-market/`

